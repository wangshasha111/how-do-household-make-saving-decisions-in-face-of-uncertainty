%% Question 3.3.2
% Evaluate Universal Basic Income

%% Step 2
% Then evaluate Andrew Young��s proposal of a UBI: Compare the stationary
% equilibrium with �� = �� = 0 to a stationary equilibrium where �� = 0:2 and the
% tax rate �� adjusts to clear the government budget. What happens to macroeconomic 
% aggregates (Y; K; C), to equilibrium prices (w; r) and the equilibrium
% distributions for earnings (1 ? ��)wyl, income (1 ? ��)wyl + ra, assets a and consumption c: 
% For the distributions, you may want to calculate Gini coefficients
% or if possible, plot the Lorenz curves, under the two different specifications. Is
% UBI welfare-improving? To answer this question you may want to compare the
% value functions v(a; y) under the two policies for some combinations of (a; y);
% or aggregate (utilitarian) social welfare

%% How I did it:
% I 